# Welcome to Microblog!

This is an example application featured in Miguel Grinberg's [Flask Mega-Tutorial](https://blog.miguelgrinberg.com/post/the-flask-mega-tutorial-part-i-hello-world). See the tutorial for instructions on how to work with it.

This is a simplified version to demo how to package an app with Docker.
See the `docker` and `compose` branches to get, respectively, a `Dockerfile` file and a `docker-compose.yml` file.